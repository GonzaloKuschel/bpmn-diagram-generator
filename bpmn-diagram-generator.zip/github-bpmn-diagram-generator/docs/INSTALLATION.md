# BPMN Process Generator Skill - Installation Guide

## ✅ How to Install This Skill for Claude

This is a **Claude skill** that provides automatic BPMN 2.0 process diagram generation. Follow these steps to install and use it.

---

## Step 1: Verify Prerequisites

- **Python 3.8+** installed on your system
- **No external dependencies** required - uses only Python standard library
- **Claude access** (claude.ai or Claude app)

---

## Step 2: Install the Skill

### Option A: Automatic Installation (Recommended)

If your Claude environment supports skill installation:

```bash
claude-skill install bpmn-process-generator
```

### Option B: Manual Installation

1. **Download all skill files** to a directory:
   ```
   bpmn-process-generator/
   ├── SKILL.md
   ├── README.md
   ├── LICENSE.txt
   ├── bpmn_processor_complete.py
   ├── bpmn_validator_tests.py
   ├── demo.py
   ├── examples/
   │   ├── simple_order_process.txt
   │   ├── credit_request_process.txt
   │   └── employee_onboarding.json
   └── scripts/
       └── quick_validate.py
   ```

2. **Verify installation**:
   ```bash
   cd bpmn-process-generator
   python3 scripts/quick_validate.py
   ```

   Expected output:
   ```
   ✓ All tests passed! Skill is ready to use.
   ```

3. **Register with Claude** (if using API):
   ```python
   import sys
   sys.path.insert(0, '/path/to/bpmn-process-generator')
   from bpmn_processor_complete import BPMNProcessor
   ```

---

## Step 3: Using the Skill with Claude

### In Claude Chat

Simply describe the process you want to model:

**Example:**
> "Generate a BPMN diagram for my order processing workflow:
> The customer places an order.
> The system validates it.
> If valid, the warehouse prepares it.
> If not, we notify the customer.
> Then we ship or close the order."

Claude will automatically:
1. ✓ Recognize this as a BPMN request
2. ✓ Use the skill to extract the process
3. ✓ Generate BPMN 2.0 XML
4. ✓ Create visualizations (SVG, Mermaid)
5. ✓ Validate the output
6. ✓ Provide download links

### In Python Code

```python
from bpmn_processor_complete import BPMNProcessor

# Initialize
processor = BPMNProcessor(language="es")

# Generate
result = processor.process(
    input_text="Your process description",
    process_name="My Process",
    output_formats=["bpmn_xml", "svg"]
)

# Use
if result["success"]:
    print(result["data"]["metadata"])
    with open("process.bpmn", "w") as f:
        f.write(result["data"]["bpmn_xml"])
```

---

## Step 4: Verify Installation

Run the quick validation:

```bash
python3 scripts/quick_validate.py
```

Or run the full demo:

```bash
python3 demo.py
```

---

## Step 5: Try Example Processes

### Simple Example
```bash
cat examples/simple_order_process.txt
# Feed to Claude or BPMNProcessor
```

### Complex Example (from meeting transcript)
```bash
cat examples/credit_request_process.txt
# Demonstrates extraction from conversational transcript
```

### Structured Example (JSON)
```bash
cat examples/employee_onboarding.json
# Shows JSON input format
```

---

## After Installation: Using the Skill

### Use Case 1: Generate from Documentation
```
User: "Create BPMN for our loan approval process"
Claude: Uses skill → Generates BPMN XML + SVG + Mermaid
```

### Use Case 2: Process Meeting Transcript
```
User: "Convert this meeting transcript into a BPMN"
Claude: Uses skill → Extracts process → Generates diagram
```

### Use Case 3: Validate Existing BPMN
```
User: "Is this BPMN valid? [uploads file]"
Claude: Uses BPMNValidator → Validates → Reports results
```

### Use Case 4: Export to Multiple Formats
```
User: "I need BPMN for Bizagi and Mermaid for documentation"
Claude: Uses skill → Generates both formats
```

---

## Troubleshooting

### Issue: "Module not found" error

**Solution**: Ensure Python path is correct
```bash
python3 -c "import sys; print(sys.path)"
# Should include the skill directory
```

### Issue: Quick validation fails

**Solution**: Check Python version
```bash
python3 --version
# Should be 3.8 or higher
```

### Issue: BPMN is invalid

**Solution**: Check input format
- Use explicit actor names: "The manager reviews" not "It is reviewed"
- Use clear decision logic: "If X, then Y, else Z"
- Avoid ambiguous descriptions

### Issue: No outputs generated

**Solution**: Enable verbose output
```python
result = processor.process(doc, verbose=True)
if not result["success"]:
    print(result["errors"])
```

---

## Configuration

### Language Selection
```python
processor = BPMNProcessor(language="en")  # English
processor = BPMNProcessor(language="pt")  # Portuguese
processor = BPMNProcessor(language="fr")  # French
```

### Output Formats
```python
processor.process(
    doc,
    output_formats=[
        "bpmn_xml",    # BPMN 2.0 XML
        "json",        # JSON structure
        "svg",         # SVG visualization
        "mermaid"      # Mermaid syntax
    ]
)
```

### Swimlane Grouping
```python
processor.process(
    doc,
    swimlane_by="role"        # Group by actor/role
    swimlane_by="department"  # Group by department
    swimlane_by="none"        # No swimlanes
)
```

---

## Next Steps

1. **Read SKILL.md** - Full specification and capabilities
2. **Run demo.py** - See all features in action
3. **Try examples/** - Test with provided processes
4. **Use with Claude** - Start generating BPMN diagrams

---

## File Structure

```
bpmn-process-generator/
├── SKILL.md                          # 👈 Skill specification
├── README.md                         # User guide
├── LICENSE.txt                       # MIT License
├── INSTALLATION.md                   # This file
├── bpmn_processor_complete.py        # Core module (1,192 lines)
├── bpmn_validator_tests.py          # Validation (393 lines)
├── demo.py                          # Demo (459 lines)
├── examples/
│   ├── simple_order_process.txt
│   ├── credit_request_process.txt
│   └── employee_onboarding.json
├── scripts/
│   └── quick_validate.py
└── agents/
    └── (reserved for future use)
```

---

## Compatibility

- ✅ **Claude**: All versions
- ✅ **Python**: 3.8+
- ✅ **Platform**: Windows, macOS, Linux
- ✅ **BPMN**: OASIS 2.0 compliant
- ✅ **Bizagi**: 5.x - 10.x
- ✅ **Camunda**: 7.18+
- ✅ **Draw.io**: 21.x+

---

## Support

### Documentation
- **SKILL.md** - Technical specification
- **README.md** - User guide
- **bpmn-process-generator-EXAMPLES.md** - Code examples
- **bpmn-process-generator-CONFIG.md** - Integration guide

### Testing
```bash
# Run tests
python3 bpmn_validator_tests.py

# Run demo
python3 demo.py

# Quick validation
python3 scripts/quick_validate.py
```

### License
MIT License - Free for commercial and personal use

---

## Success Checklist

After installation, verify:

- [ ] Python 3.8+ installed
- [ ] Skill files downloaded
- [ ] `quick_validate.py` passes
- [ ] `demo.py` runs successfully
- [ ] Can import BPMNProcessor in Python
- [ ] Can access examples/ directory
- [ ] Can use skill with Claude

---

## You're Ready! 🚀

The skill is installed and ready to generate BPMN diagrams automatically.

**Try it now:**
1. Ask Claude to "Generate a BPMN diagram for..."
2. Or run: `python3 demo.py`
3. Or import: `from bpmn_processor_complete import BPMNProcessor`

---

**Questions?** Check README.md or SKILL.md for comprehensive documentation.

**Version**: 1.0  
**Status**: Production Ready ✅  
**License**: MIT
