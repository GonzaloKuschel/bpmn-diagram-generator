---
name: bpmn-process-generator
description: Generates BPMN 2.0 compliant process diagrams from documentation, transcriptions, and structured data. Automates process modeling for Bizagi, Camunda, and Draw.io.
license: MIT License - See LICENSE.txt
---

# BPMN Process Generator Skill

## Overview

The **BPMN Process Generator** skill automatically generates BPMN 2.0 compliant process diagrams from multiple input sources:

- **Documentación en prosa**: Descripciones textuales de procesos
- **Transcripciones de reuniones**: Convertir conversaciones (Zoom, Teams, Meet) en BPMN
- **Entrada JSON estructurada**: Procesos pre-formateados
- **Auto-detección**: Identificar automáticamente el formato

## What This Skill Does

### Automatic Process Extraction
- Extracts actors, roles, and responsibilities
- Identifies tasks, activities, and workflows
- Detects decision points and conditional logic
- Recognizes sequence flows and dependencies
- Maps responsibilities to swimlanes

### BPMN 2.0 XML Generation
Generates **100% valid BPMN 2.0 OASIS-compliant XML** with:
- Start/End events
- Task elements with proper attributes
- Exclusive gateways for decisions
- Sequence flows with conditions
- Swimlanes (lanes) with assigned actors
- Diagram Interchange (DI) for visual positioning
- Unique IDs and descriptive names

### Multiple Output Formats
1. **BPMN 2.0 XML** - Direct import into Bizagi, Camunda, Draw.io
2. **JSON** - Structured data for programmatic use
3. **SVG** - Rendered diagram visualization
4. **Mermaid** - Markdown-compatible flowcharts

### Comprehensive Validation
- BPMN 2.0 schema compliance verification
- Structural integrity checking
- Connected flows validation
- Balanced gateway detection
- Unique ID verification
- Detailed validation reports

## When to Use This Skill

Use this skill when the user:
- Needs to generate BPMN diagrams from text descriptions
- Has process documentation they want to model
- Wants to convert meeting transcriptions into BPMN
- Needs to create process flows for Bizagi or Camunda
- Requires multiple export formats for a process
- Wants to validate existing BPMN models
- Needs to automate process diagram creation

**Trigger keywords**: 
- "generate BPMN", "create process diagram", "model process", "BPMN from"
- "process flow", "workflow diagram", "bizagi", "camunda"
- "document process", "visualize workflow", "process documentation"
- Any mention of process modeling combined with text/documentation

## How to Use This Skill

### Basic Usage

User provides process documentation:
```
"El cliente solicita un producto. 
El vendedor revisa el stock.
Si hay disponible, prepara la factura.
Si no, avisa al cliente.
Se notifica el resultado."
```

You respond:
```python
from bpmn_processor_complete import BPMNProcessor

processor = BPMNProcessor(language="es")
result = processor.process(
    input_text=user_text,
    process_name="Gestión de Pedidos",
    swimlane_by="role",
    output_formats=["bpmn_xml", "svg"]
)

if result["success"]:
    # Provide BPMN XML
    # Render SVG diagram
    # Show metadata
    # Validate with validator
```

### Advanced Usage

**From meeting transcription**:
```python
result = processor.process(
    input_text=transcript,
    process_name="Extracted from Meeting",
    input_type="transcript"
)
```

**With custom configuration**:
```python
result = processor.process(
    input_text=doc,
    process_name="Custom Process",
    swimlane_by="department",  # or "role", "none"
    output_formats=["bpmn_xml", "json", "svg", "mermaid"],
    language="es"
)
```

**With validation**:
```python
from bpmn_validator_tests import BPMNValidator

validator = BPMNValidator()
validation = validator.validate_xml(result["data"]["bpmn_xml"])

if validation["valid"]:
    # BPMN is valid
else:
    # Show errors and warnings
```

## Input Formats

### 1. Narrative Documentation
Plain text describing the process in natural language:
- Spanish, English, Portuguese, French
- Free-form prose or numbered steps
- Includes decision points using "si/sino", "según", "if/then"
- Mentions actors explicitly or implicitly

Example:
```
"El cliente inicia la solicitud. 
El sistema valida. 
Si es válida, se procesa. 
Si no, se rechaza."
```

### 2. Meeting Transcription
Raw transcription from video meetings:
- Zoom, Microsoft Teams, Google Meet transcripts
- Casual conversation format
- Multiple speakers
- May include filler words and interruptions

Example:
```
"Person A: Bueno, entonces cuando llega una solicitud...
Person B: Exacto, el cliente la envía por email...
Person A: Ok, entonces el vendedor revisa el stock..."
```

### 3. JSON Structured Data
Pre-formatted process definition:
```json
{
  "nombre_proceso": "Solicitud de Crédito",
  "actores": [
    {"id": "cliente", "nombre": "Cliente"},
    {"id": "gerente", "nombre": "Gerente"}
  ],
  "pasos": [
    {
      "id": 1,
      "nombre": "Solicitar crédito",
      "actor": "cliente",
      "tipo": "tarea"
    }
  ]
}
```

## Output Formats

### BPMN 2.0 XML
Full BPMN 2.0 XML with:
- `<bpmn2:definitions>` root element
- `<bpmn2:collaboration>` with participants
- `<bpmn2:process>` with laneSet
- `<bpmn2:startEvent>`, `<bpmn2:endEvent>`
- `<bpmn2:task>` elements
- `<bpmn2:exclusiveGateway>` for decisions
- `<bpmn2:sequenceFlow>` with conditions
- `<bpmn2:BPMNDiagram>` with DI information

**Use case**: Import into Bizagi Studio, Camunda Modeler, or Draw.io

### JSON
Structured representation:
```json
{
  "id": "Process_1",
  "name": "Process Name",
  "elements": { /* BPMNElement objects */ },
  "flows": { /* SequenceFlow objects */ },
  "lanes": { /* Lane objects */ }
}
```

**Use case**: Programmatic processing, integration with other systems

### SVG
Rendered diagram with:
- Swimlanes for each actor
- Elements positioned automatically
- Color-coded by type (green events, blue tasks, gold decisions)
- Arrows showing flow direction
- Labels for conditions (Yes/No)

**Use case**: Web display, documentation, email distribution

### Mermaid
Markdown-compatible syntax:
```mermaid
graph TD
    A["Cliente solicita"] --> B["Revisar"]
    B --> C{"¿Válido?"}
    C -->|Sí| D["Procesar"]
    C -->|No| E["Rechazar"]
```

**Use case**: GitHub README, markdown documentation, wiki pages

## Parameters

### Main Parameters
```python
processor.process(
    input_text: str,              # Required: process description
    process_name: str = "Process",  # Optional: custom name
    swimlane_by: str = "role",    # "role" | "department" | "none"
    output_formats: list = [...],  # ["bpmn_xml", "json", "svg", "mermaid"]
    language: str = "es"           # "es" | "en" | "pt" | "fr"
)
```

### Return Value
```python
{
    "success": bool,
    "data": {
        "bpmn_xml": str,           # BPMN 2.0 XML (if requested)
        "json": dict,              # Structured data (if requested)
        "svg": str,                # SVG diagram (if requested)
        "mermaid": str,            # Mermaid syntax (if requested)
        "metadata": {
            "process_name": str,
            "elements_count": int,
            "flows_count": int,
            "lanes_count": int,
            "actors": list,
            "tasks_count": int,
            "decisions_count": int
        }
    },
    "errors": list
}
```

## Examples

### Example 1: Simple Process
**User**: "Generate a BPMN for a simple order process where the customer requests a product, the seller checks stock, and then either prepares an invoice or notifies the customer."

**You use the skill**:
```python
result = processor.process(
    input_text=user_message,
    process_name="Order Process",
    output_formats=["bpmn_xml", "svg"]
)
```

**Result**: 
- BPMN XML file ready for import
- SVG visualization showing swimlanes for Customer and Seller
- Metadata showing 2 actors, 3 tasks, 1 decision

### Example 2: From Meeting Transcript
**User**: (uploads or provides meeting transcript about credit request process)

**You use the skill**:
```python
result = processor.process(
    input_text=transcript,
    process_name="Credit Request (from meeting)",
    input_type="transcript"
)
```

**Result**:
- Extracted actors (HR, Finance, Manager)
- Identified tasks (validate, review, approve)
- Detected decision points
- Generated BPMN with all elements properly mapped

### Example 3: Multiple Formats
**User**: "Create BPMN for my service request process and give me formats I can use in Bizagi and in markdown documentation."

**You use the skill**:
```python
result = processor.process(
    input_text=user_text,
    process_name="Service Request",
    output_formats=["bpmn_xml", "mermaid", "svg"]
)
```

**Result**:
- BPMN XML for Bizagi import
- Mermaid diagram for markdown docs
- SVG for visual reference

### Example 4: With Validation
**User**: "Create and validate a BPMN process for my loan approval workflow."

**You use the skill**:
```python
result = processor.process(input_text=doc)

# Validate result
from bpmn_validator_tests import BPMNValidator
validator = BPMNValidator()
validation = validator.validate_xml(result["data"]["bpmn_xml"])

if validation["valid"]:
    # Share BPMN with validation confirmation
```

**Result**:
- BPMN generated and validated
- Confirmation that it meets BPMN 2.0 standards
- Ready to import into Bizagi

## Key Features

### Intelligent NLP Processing
- **Actor Identification**: Automatically detects roles from context
- **Task Extraction**: Identifies actions using verb analysis
- **Decision Detection**: Recognizes conditional logic (if/then, according to, depends on)
- **Flow Analysis**: Maps sequence and dependencies
- **Responsibility Mapping**: Assigns tasks to correct swimlanes

### BPMN 2.0 Compliance
- **Full Specification Support**: All required and optional elements
- **Valid XML Structure**: OASIS-compliant
- **Diagram Interchange**: Automatic positioning information
- **Namespace Handling**: Correct BPMN 2.0 namespaces
- **Element Validation**: Proper incoming/outgoing flow references

### Automatic Layout
- **Topological Ordering**: Elements ordered by flow dependency
- **Swimlane Distribution**: Tasks assigned to correct actors
- **Position Calculation**: Automatic X,Y coordinates
- **Flow Routing**: Proper waypoint generation

### Quality Assurance
- **Comprehensive Validation**: Check every BPMN requirement
- **Error Reporting**: Detailed error and warning messages
- **Ambiguity Detection**: Marks uncertain elements with [?]
- **Best Practices**: Warns about BPMN anti-patterns

## Language Support
- **Español** (Spanish) - Default, optimized pattern matching
- **English** - Supported
- **Português** (Portuguese) - Supported
- **Français** (French) - Supported

## Integration with Tools

### Bizagi Studio
Import generated BPMN directly:
1. File → Import → BPMN 2.0 (.bpmn)
2. Select generated file
3. Process available for editing and execution

### Camunda Modeler
1. Open BPMN file
2. File → Open BPMN Diagram
3. Edit and add Camunda-specific extensions

### Draw.io
1. File → Import from → Device
2. Select .bpmn or .svg
3. Edit in Draw.io interface

### GitHub/Markdown
1. Use generated Mermaid syntax
2. Paste in .md files
3. Automatically renders in GitHub

## Limitations

- **Complex Logic**: Highly complex nested conditions may require manual refinement
- **Ambiguous Input**: Vague process descriptions need clarification
- **Timing Data**: Duration estimates require explicit inclusion
- **Advanced Gateways**: Parallel and inclusive gateways use exclusive as default

## Future Enhancements

- [ ] Support for parallel gateways
- [ ] Sub-process detection and modeling
- [ ] Resource/cost allocation
- [ ] Integration with Google Meet/Zoom APIs for auto-transcription
- [ ] Process simulation and analysis
- [ ] Performance metrics extraction
- [ ] Risk and bottleneck analysis

## Technical Stack

- **Language**: Python 3.8+
- **Core Libraries**: Only Python standard library
  - `xml.etree.ElementTree` - XML generation
  - `re` - Pattern matching for NLP
  - `dataclasses` - Type safety
  - `json` - Data serialization
- **No External Dependencies**: Runs anywhere

## File Structure

```
skill-directory/
├── SKILL.md                              # This specification
├── LICENSE.txt                           # MIT License
├── bpmn_processor_complete.py            # Core module (1,192 lines)
├── bpmn_validator_tests.py              # Validation module (393 lines)
├── demo.py                              # Interactive demo (459 lines)
├── examples/
│   ├── simple_order_process.txt
│   ├── credit_request_process.txt
│   └── service_workflow.txt
└── README.md                            # User documentation
```

## How Claude Uses This Skill

When a user asks for BPMN generation or process modeling:

1. **Recognize the request** - Detect process diagram/BPMN keywords
2. **Extract input** - Get process description from user message
3. **Initialize processor** - Create BPMNProcessor instance
4. **Process document** - Call process() with appropriate parameters
5. **Generate outputs** - Receive BPMN XML, JSON, SVG, Mermaid
6. **Validate** (optional) - Use BPMNValidator to verify BPMN
7. **Present results** - Show metadata, render diagram, provide download links
8. **Offer next steps** - Suggest importing into Bizagi, using in documentation, etc.

## Example Skill Invocation

```python
# When user says: "Create a BPMN diagram for my loan approval process"

from bpmn_processor_complete import BPMNProcessor
from bpmn_validator_tests import BPMNValidator

# Initialize
processor = BPMNProcessor(language="es")

# Process
result = processor.process(
    input_text=user_provided_description,
    process_name="Loan Approval Process",
    swimlane_by="role",
    output_formats=["bpmn_xml", "svg"]
)

# Validate
if result["success"]:
    validator = BPMNValidator()
    validation = validator.validate_xml(result["data"]["bpmn_xml"])
    
    # Present to user
    # - Show SVG diagram
    # - Provide BPMN XML for download
    # - Show validation results
    # - Suggest next steps (import to Bizagi, etc.)
```

## Support and Documentation

- **Full Documentation**: See README.md
- **Technical Examples**: See examples/ directory
- **API Reference**: See docstrings in .py files
- **Tests**: Run bpmn_validator_tests.py
- **Live Demo**: Run demo.py

## License

MIT License - Free for commercial and personal use

## Version

- **Version**: 1.0
- **Release Date**: 2025-05-05
- **BPMN Standard**: OASIS BPMN 2.0
- **Python**: 3.8+

---

**This skill transforms process descriptions into production-ready BPMN 2.0 diagrams in seconds.**
