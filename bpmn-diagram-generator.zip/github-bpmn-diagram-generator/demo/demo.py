#!/usr/bin/env python3
"""
BPMN Generator - Demo Ejecutable
Demuestra todas las capacidades del sistema con ejemplos prácticos
"""

import sys
import os

# Agregar ruta actual al path para importar módulos
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from bpmn_processor_complete import BPMNProcessor
from bpmn_validator_tests import BPMNValidator


def print_header(text):
    """Imprime encabezado formateado"""
    print("\n" + "="*70)
    print(f"  {text}")
    print("="*70 + "\n")


def print_section(text):
    """Imprime sección formateada"""
    print(f"\n📌 {text}")
    print("-" * 70)


def demo_simple_process():
    """Demostración: Proceso Simple"""
    print_header("DEMO 1: Proceso Simple")
    
    doc = """
    El cliente solicita un producto.
    El vendedor revisa el stock.
    Si hay disponible, prepara la factura y la envía.
    Si no, avisa al cliente que no hay disponibilidad.
    Se cierra la solicitud.
    """
    
    print_section("Entrada: Documentación del proceso")
    print(doc)
    
    processor = BPMNProcessor(language="es")
    
    print_section("Procesando...")
    result = processor.process(
        input_text=doc,
        process_name="Gestión de Pedidos",
        swimlane_by="role",
        output_formats=["bpmn_xml", "json", "svg"]
    )
    
    if result["success"]:
        metadata = result["data"]["metadata"]
        
        print_section("Resultado: Metadatos del Proceso")
        print(f"✓ Nombre del proceso: {metadata['process_name']}")
        print(f"✓ Elementos totales: {metadata['elements_count']}")
        print(f"✓ Flujos de secuencia: {metadata['flows_count']}")
        print(f"✓ Swimlanes/Actores: {metadata['lanes_count']}")
        print(f"✓ Actores identificados: {', '.join(metadata['actors'])}")
        print(f"✓ Tareas identificadas: {metadata['tasks_count']}")
        print(f"✓ Puntos de decisión: {metadata['decisions_count']}")
        
        # Guardar archivos
        output_dir = "output_demo"
        os.makedirs(output_dir, exist_ok=True)
        
        with open(f"{output_dir}/pedidos.bpmn", "w", encoding="utf-8") as f:
            f.write(result["data"]["bpmn_xml"])
        
        with open(f"{output_dir}/pedidos.svg", "w", encoding="utf-8") as f:
            f.write(result["data"]["svg"])
        
        print_section("Archivos Generados")
        print(f"✓ {output_dir}/pedidos.bpmn - Diagrama BPMN 2.0 XML")
        print(f"✓ {output_dir}/pedidos.svg - Visualización SVG")
        
        return result["data"]["bpmn_xml"]
    else:
        print(f"✗ Error: {result['errors']}")
        return None


def demo_complex_process():
    """Demostración: Proceso Complejo con múltiples actores y decisiones"""
    print_header("DEMO 2: Proceso Complejo - Solicitud de Crédito")
    
    doc = """
    1. El cliente inicia la solicitud de crédito online
    2. El sistema valida que la solicitud esté completa
    3. Si la solicitud está incompleta:
       - Se solicita documentación adicional
       - El cliente la envía
       - Se vuelve al paso 2 para revalidar
    4. Si está completa:
       - El analista de crédito revisa la información
       - El gerente de crédito evalúa el monto y la capacidad de pago
       - Si el análisis es favorable (aprobado):
         * Se genera el contrato
         * Se envía al cliente por email
         * El cliente firma
       - Si el análisis es desfavorable (rechazado):
         * Se notifica el rechazo
         * Se cierra la solicitud
    5. Una vez que el cliente firma, se confirma en el sistema
    6. Se generan los documentos finales
    7. Se cierra el expediente y se archiván los documentos
    """
    
    print_section("Entrada: Documentación compleja con múltiples actores")
    print(doc)
    
    processor = BPMNProcessor(language="es")
    
    print_section("Procesando...")
    result = processor.process(
        input_text=doc,
        process_name="Solicitud de Crédito",
        swimlane_by="role",
        output_formats=["bpmn_xml", "json", "svg", "mermaid"]
    )
    
    if result["success"]:
        metadata = result["data"]["metadata"]
        
        print_section("Resultado: Proceso Extraído")
        print(f"✓ Nombre: {metadata['process_name']}")
        print(f"✓ Elementos: {metadata['elements_count']}")
        print(f"✓ Flujos: {metadata['flows_count']}")
        print(f"✓ Swimlanes: {metadata['lanes_count']}")
        print(f"✓ Actores: {', '.join(metadata['actors'])}")
        print(f"✓ Tareas: {metadata['tasks_count']}")
        print(f"✓ Decisiones: {metadata['decisions_count']}")
        
        # Guardar archivos
        output_dir = "output_demo"
        os.makedirs(output_dir, exist_ok=True)
        
        with open(f"{output_dir}/credito.bpmn", "w", encoding="utf-8") as f:
            f.write(result["data"]["bpmn_xml"])
        
        with open(f"{output_dir}/credito.svg", "w", encoding="utf-8") as f:
            f.write(result["data"]["svg"])
        
        with open(f"{output_dir}/credito.mermaid", "w", encoding="utf-8") as f:
            f.write(result["data"]["mermaid"])
        
        print_section("Archivos Generados")
        print(f"✓ {output_dir}/credito.bpmn - BPMN 2.0 XML")
        print(f"✓ {output_dir}/credito.svg - Visualización SVG")
        print(f"✓ {output_dir}/credito.mermaid - Diagrama Mermaid")
        
        return result["data"]["bpmn_xml"]
    else:
        print(f"✗ Error: {result['errors']}")
        return None


def demo_validation(bpmn_xml):
    """Demostración: Validación BPMN 2.0"""
    print_header("DEMO 3: Validación BPMN 2.0")
    
    if not bpmn_xml:
        print("✗ No hay BPMN XML para validar")
        return
    
    print_section("Validando BPMN 2.0 Compliance")
    
    validator = BPMNValidator()
    validation = validator.validate_xml(bpmn_xml)
    
    print(f"Resultado: {'✓ VÁLIDO' if validation['valid'] else '✗ INVÁLIDO'}")
    print(f"Errores: {validation['summary']['total_errors']}")
    print(f"Advertencias: {validation['summary']['total_warnings']}")
    print(f"Información: {validation['summary']['total_info']}")
    
    if validation['errors']:
        print_section("Errores Encontrados")
        for error in validation['errors']:
            print(f"  ✗ {error}")
    
    if validation['warnings']:
        print_section("Advertencias")
        for warning in validation['warnings']:
            print(f"  ⚠ {warning}")
    
    print_section("Validaciones Realizadas")
    for info in validation['info'][:10]:
        print(f"  {info}")
    
    if len(validation['info']) > 10:
        print(f"  ... y {len(validation['info']) - 10} validaciones más")


def demo_multiple_formats():
    """Demostración: Exportación a múltiples formatos"""
    print_header("DEMO 4: Exportación a Múltiples Formatos")
    
    doc = """
    Se recibe una solicitud de servicio.
    Se valida que la solicitud esté completa.
    Si está completa, se asigna a un técnico.
    Si no, se solicita información adicional.
    El técnico realiza el servicio.
    Se registra el resultado.
    Se cierra la solicitud.
    """
    
    print_section("Entrada: Proceso de Servicio Técnico")
    print(doc)
    
    processor = BPMNProcessor(language="es")
    
    print_section("Generando en múltiples formatos...")
    result = processor.process(
        input_text=doc,
        process_name="Gestión de Servicio Técnico",
        swimlane_by="role",
        output_formats=["bpmn_xml", "json", "svg", "mermaid"]
    )
    
    if result["success"]:
        output_dir = "output_demo"
        os.makedirs(output_dir, exist_ok=True)
        
        # Guardar en múltiples formatos
        formats = {
            "bpmn_xml": ("servicio.bpmn", "BPMN 2.0 XML (importable en Bizagi/Camunda)"),
            "svg": ("servicio.svg", "SVG Diagrama (visualización web)"),
            "mermaid": ("servicio.mermaid", "Mermaid (documentación markdown)"),
        }
        
        print_section("Formatos Generados")
        
        for key, (filename, description) in formats.items():
            if key in result["data"]:
                filepath = f"{output_dir}/{filename}"
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write(result["data"][key])
                print(f"✓ {filename:<20} - {description}")
        
        # JSON especial
        import json
        with open(f"{output_dir}/servicio.json", "w", encoding="utf-8") as f:
            json.dump(result["data"]["json"], f, indent=2, ensure_ascii=False)
        print(f"✓ {'servicio.json':<20} - Estructura de datos JSON")
        
        print_section("Información")
        print(f"Todos los archivos guardados en: {output_dir}/")
        print(f"\nUsos de cada formato:")
        print(f"  • BPMN XML: Importar en Bizagi/Camunda (File > Import)")
        print(f"  • SVG: Insertar en HTML o documentación")
        print(f"  • Mermaid: Usar en Markdown/GitHub")
        print(f"  • JSON: Procesar programáticamente")


def demo_imports():
    """Demostración: Cómo importar en herramientas"""
    print_header("DEMO 5: Instrucciones de Importación")
    
    print_section("Importar en Bizagi Studio")
    print("""
    1. Abre Bizagi Studio
    2. Ve a File → Import → BPMN 2.0 (.bpmn)
    3. Selecciona el archivo generado (ej: pedidos.bpmn)
    4. El proceso se importará automáticamente
    5. Puedes editarlo y ajustar visualmente en Bizagi
    """)
    
    print_section("Importar en Draw.io")
    print("""
    1. Abre https://app.diagrams.net/
    2. Ve a File → Import from → Device
    3. Selecciona el archivo .bpmn o .svg
    4. El diagrama se abrirá en Draw.io
    5. Puedes editarlo y exportar a múltiples formatos
    """)
    
    print_section("Importar en Camunda Modeler")
    print("""
    1. Abre Camunda Modeler
    2. Ve a File → Import BPMN 2.0 Diagram
    3. Selecciona el archivo .bpmn
    4. Se abrirá para edición y simulación
    5. Puedes agregar elementos Camunda específicos
    """)
    
    print_section("Usar en Documentación Markdown")
    print("""
    En tu README.md o documento Markdown:
    
    # Mi Proceso
    
    ```mermaid
    graph TD
        A["🟢 Inicio"] --> B["📋 Tarea"]
        B --> C{"¿Decisión?"}
        C -->|Sí| D["✓ Fin"]
        C -->|No| E["✗ Fin"]
    ```
    
    GitHub renderizará automáticamente el diagrama Mermaid.
    """)


def show_statistics():
    """Muestra estadísticas y información del sistema"""
    print_header("Sistema BPMN Generator - Información General")
    
    print_section("Capacidades")
    print("""
    ✓ Extracción automática de procesos desde texto
    ✓ Identificación de actores, tareas y decisiones
    ✓ Generación de BPMN 2.0 XML válido
    ✓ Creación de swimlanes por rol
    ✓ Validación completa BPMN 2.0
    ✓ Exportación a múltiples formatos
    ✓ Visualización SVG con posicionamiento automático
    ✓ Diagramas Mermaid para documentación
    """)
    
    print_section("Formatos de Salida")
    print("""
    1. BPMN 2.0 XML
       • Compatible con Bizagi, Camunda, Draw.io
       • Incluye Diagram Interchange (DI)
       • OASIS compliant
    
    2. JSON
       • Estructura de datos completa
       • Fácil de procesar programáticamente
    
    3. SVG
       • Diagrama visual renderizado
       • Incluye swimlanes, eventos, tareas, gateways
       • Flujos con flechas y etiquetas
    
    4. Mermaid
       • Sintaxis Markdown compatible
       • Perfecto para documentación
       • Renderizable en GitHub
    """)
    
    print_section("Elementos BPMN Soportados")
    print("""
    • Start Event (🟢 Inicio)
    • End Event (🔴 Fin)
    • Task (📋 Tarea)
    • Exclusive Gateway (⬧ Decisión)
    • Sequence Flow (→ Flujo)
    • Lanes (║ Swimlanes)
    • Conditions (etiquetas Si/No)
    • Documentation (descripciones)
    """)
    
    print_section("Idiomas Soportados")
    print("""
    ✓ Español (es)
    ✓ English (en)
    ✓ Português (pt)
    ✓ Français (fr)
    """)


def main():
    """Función principal - Ejecuta todas las demostraciones"""
    
    print("\n")
    print("╔" + "="*68 + "╗")
    print("║" + " "*68 + "║")
    print("║" + "  BPMN PROCESS GENERATOR - DEMO COMPLETO".center(68) + "║")
    print("║" + "  Generador automático de diagramas BPMN 2.0".center(68) + "║")
    print("║" + " "*68 + "║")
    print("╚" + "="*68 + "╝")
    
    # Mostrar información general
    show_statistics()
    
    # Demo 1: Proceso simple
    bpmn_xml_1 = demo_simple_process()
    
    # Demo 2: Proceso complejo
    bpmn_xml_2 = demo_complex_process()
    
    # Demo 3: Validación
    demo_validation(bpmn_xml_1)
    
    # Demo 4: Múltiples formatos
    demo_multiple_formats()
    
    # Demo 5: Instrucciones de importación
    demo_imports()
    
    # Resumen final
    print_header("RESUMEN Y PRÓXIMOS PASOS")
    
    print_section("Archivos Generados")
    print("""
    Todos los archivos de demostración están en: ./output_demo/
    
    Archivo                    Descripción
    ───────────────────────────────────────────────────────────
    pedidos.bpmn              Proceso BPMN de Gestión de Pedidos
    pedidos.svg               Visualización SVG del proceso
    credito.bpmn              Proceso BPMN de Solicitud de Crédito
    credito.svg               Visualización SVG del proceso
    credito.mermaid           Diagrama Mermaid del proceso
    servicio.bpmn             Proceso BPMN de Servicio Técnico
    servicio.svg              Visualización SVG del proceso
    servicio.json             Datos JSON del proceso
    servicio.mermaid          Diagrama Mermaid del proceso
    """)
    
    print_section("Próximos Pasos")
    print("""
    1. Abre cualquier archivo .bpmn en Bizagi o Draw.io
    2. Revisa la visualización SVG en un navegador
    3. Integra los diagramas Mermaid en tu documentación
    4. Usa el archivo JSON para procesar datos
    
    Para tu propio proceso:
    
    from bpmn_processor_complete import BPMNProcessor
    
    processor = BPMNProcessor(language="es")
    result = processor.process(
        input_text="Tu descripción del proceso aquí",
        process_name="Nombre del Proceso",
        output_formats=["bpmn_xml", "svg"]
    )
    """)
    
    print_section("Contacto y Soporte")
    print("""
    Para más información:
    • Documentación: Ver README.md
    • Tests: Ejecutar bpmn_validator_tests.py
    • Especificación BPMN 2.0: https://www.omg.org/spec/BPMN/2.0/
    """)
    
    print("\n" + "="*70)
    print("✓ DEMO COMPLETADA EXITOSAMENTE".center(70))
    print("="*70 + "\n")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n✗ Operación cancelada por el usuario")
        sys.exit(1)
    except Exception as e:
        print(f"\n✗ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
