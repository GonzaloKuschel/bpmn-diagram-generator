#!/usr/bin/env python3
"""
Demostración de la nueva funcionalidad v1.1:
Responsables y Roles en Lanes
"""

import sys
import os

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def demo_roles_and_responsibilities():
    """Demostración de roles y responsabilidades en lanes"""
    
    print("""
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║          BPMN Diagram Generator v1.1 - NEW FEATURES           ║
║                                                                ║
║              Roles & Responsibilities in Lanes                ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝

Esta demostración muestra las NUEVAS capacidades:
  ✓ Detección automática de roles
  ✓ Asignación de responsabilidades
  ✓ Información de departamentos
  ✓ Visualización mejorada en SVG
  ✓ Documentación en XML BPMN

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EJEMPLO 1: PROCESO DE SOLICITUD DE CRÉDITO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Descripción del Proceso:
""")
    
    credit_process = """
El cliente solicita un crédito completando el formulario.
El gerente revisa la solicitud y documenta completitud.
Si la documentación está completa, el contador evalúa el crédito.
Si no está completa, el gerente solicita documentación adicional.
El contador analiza el historial crediticio y capacidad de pago.
Se aprueba o se rechaza la solicitud.
El cliente es notificado del resultado.
"""
    
    print(credit_process)
    
    try:
        from bpmn_processor_complete import BPMNProcessor
        
        print("\n[Procesando proceso de crédito...]")
        processor = BPMNProcessor(language="es")
        
        result = processor.process(
            input_text=credit_process,
            process_name="Credit Request Process",
            swimlane_by="role",
            output_formats=["json"]
        )
        
        if result["success"]:
            print("✓ Proceso procesado exitosamente\n")
            
            # Mostrar información de lanes
            lanes_info = result["data"]["json"].get("lanes", {})
            
            if lanes_info:
                print("📊 INFORMACIÓN DE LANES EXTRAÍDA:\n")
                
                for lane_id, lane_data in lanes_info.items():
                    print(f"  Lane: {lane_data.get('name', 'Unknown')}")
                    print(f"    ID: {lane_id}")
                    
                    if 'role' in lane_data and lane_data['role']:
                        print(f"    ✓ Role: {lane_data['role']}")
                    
                    if 'department' in lane_data and lane_data['department']:
                        print(f"    ✓ Department: {lane_data['department']}")
                    
                    if 'responsibilities' in lane_data and lane_data['responsibilities']:
                        resp = lane_data['responsibilities']
                        if len(resp) > 60:
                            resp = resp[:60] + "..."
                        print(f"    ✓ Responsibilities: {resp}")
                    
                    if 'elements' in lane_data and lane_data['elements']:
                        print(f"    ✓ Tasks: {len(lane_data['elements'])} elementos")
                    
                    print()
        else:
            print(f"✗ Error: {result.get('errors', ['Unknown error'])}")
    
    except Exception as e:
        print(f"✗ Error: {e}")
    
    print("\n" + "━"*60)
    print("VISUALIZACIÓN EN SVG CON ROLES")
    print("━"*60 + "\n")
    
    print("""
Los diagramas SVG ahora muestran información de roles:

┌─────────────────────────────────────────────────┐
│  CLIENTE (Client)                               │
│  ┌───────────────────────────────────────────┐  │
│  │ Role: Client                              │  │
│  │ Department: External                      │  │
│  │ Responsibilities: Initiates requests...   │  │
│  └───────────────────────────────────────────┘  │
│                                                 │
│  [Request Credit]                              │
│        ↓                                        │
└─────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────┐
│  GERENTE (Manager)                              │
│  ┌───────────────────────────────────────────┐  │
│  │ Role: Manager                             │  │
│  │ Department: Management                    │  │
│  │ Responsibilities: Reviews and approves... │  │
│  └───────────────────────────────────────────┘  │
│                                                 │
│  [Review] → ◇ Complete? ─→ [Request Docs]    │
│        ↓                                        │
└─────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────┐
│  CONTADOR (Accountant)                          │
│  ┌───────────────────────────────────────────┐  │
│  │ Role: Accountant                          │  │
│  │ Department: Finance                       │  │
│  │ Responsibilities: Manages financial...    │  │
│  └───────────────────────────────────────────┘  │
│                                                 │
│  [Evaluate] → [Approve/Reject]                │
│        ↓                                        │
└─────────────────────────────────────────────────┘
""")
    
    print("\n" + "━"*60)
    print("INFORMACIÓN EN BPMN XML")
    print("━"*60 + "\n")
    
    print("""
Cada lane ahora incluye documentación completa:

<laneSet id="LaneSet_1">

  <lane id="lane_cliente" name="Cliente">
    <documentation>
      Lane: Cliente
      Role: Client
      Department: External
      Responsibilities: Initiates requests and provides information
    </documentation>
    <flowNodeRef>task_request</flowNodeRef>
    <!-- ... elementos ... -->
  </lane>

  <lane id="lane_gerente" name="Gerente">
    <documentation>
      Lane: Gerente
      Role: Manager
      Department: Management
      Responsibilities: Reviews and approves decisions
    </documentation>
    <flowNodeRef>task_review</flowNodeRef>
    <!-- ... elementos ... -->
  </lane>

  <lane id="lane_contador" name="Contador">
    <documentation>
      Lane: Contador
      Role: Accountant
      Department: Finance
      Responsibilities: Manages financial transactions
    </documentation>
    <flowNodeRef>task_evaluate</flowNodeRef>
    <!-- ... elementos ... -->
  </lane>

</laneSet>
""")
    
    print("\n" + "━"*60)
    print("ROLES PREDEFINIDOS AUTOMÁTICOS")
    print("━"*60 + "\n")
    
    roles_mapping = {
        "Cliente": ("Client", "External", "Initiates requests"),
        "Vendedor": ("Sales Rep", "Sales", "Processes orders"),
        "Gerente": ("Manager", "Management", "Reviews decisions"),
        "Contador": ("Accountant", "Finance", "Manages financial"),
        "Administrador": ("Administrator", "IT", "Maintains systems"),
        "Sistema": ("System", "IT", "Processes automation"),
    }
    
    print("El sistema detecta automáticamente estos roles:\n")
    for actor, (role, dept, resp) in roles_mapping.items():
        print(f"  {actor:15} → {role:20} ({dept:15}) - {resp}...")
    
    print("\n" + "━"*60)
    print("EJEMPLO 2: PROCESO DE PEDIDO SIMPLE")
    print("━"*60 + "\n")
    
    simple_process = """
El cliente realiza un pedido.
El vendedor recibe el pedido y lo valida.
Si es válido, el almacén prepara el envío.
Si no es válido, se notifica al cliente.
El cliente recibe el pedido o la notificación.
"""
    
    print("Descripción del Proceso:")
    print(simple_process)
    
    print("\nRoles Detectados:")
    print("  • Cliente (Role: Client, Dept: External)")
    print("  • Vendedor (Role: Sales Rep, Dept: Sales)")
    print("  • Almacén (Role: Warehouse Manager, Dept: Operations)")
    
    print("\n" + "━"*60)
    print("BENEFICIOS DE LAS NUEVAS CARACTERÍSTICAS")
    print("━"*60 + "\n")
    
    benefits = [
        ("Claridad", "Roles y responsabilidades explícitamente definidos"),
        ("Automatización", "Detección inteligente sin configuración manual"),
        ("Comunicación", "Diagramas auto-explicativos para stakeholders"),
        ("Cumplimiento", "Documentación de responsabilidades para auditoría"),
        ("Integración", "Compatible con Bizagi, Camunda, Draw.io"),
        ("Multiidioma", "Soporta español, inglés, portugués, francés"),
    ]
    
    for title, desc in benefits:
        print(f"  ✓ {title:15} - {desc}")
    
    print("\n" + "━"*60)
    print("PRÓXIMAS CARACTERÍSTICAS PLANEADAS")
    print("━"*60 + "\n")
    
    upcoming = [
        "Sub-proceso detection y modelado",
        "Parallel Gateways (paralelización)",
        "Análisis automático de riesgos",
        "Detección de cuellos de botella",
        "Métricas de complejidad del proceso",
        "Sugerencias de mejora automáticas",
    ]
    
    for feature in upcoming:
        print(f"  [ ] {feature}")
    
    print("\n" + "━"*60)
    print("✅ DEMOSTRACIÓN COMPLETADA")
    print("━"*60 + "\n")
    
    print("Para usar estas características:\n")
    print("  1. Pedir a Claude:")
    print('     "Generate a BPMN diagram for my process..."')
    print("     → El skill usará automáticamente la nueva funcionalidad\n")
    
    print("  2. O usar directamente:")
    print("     processor = BPMNProcessor()")
    print("     result = processor.process(your_process)")
    print("     → Roles se detectan automáticamente\n")
    
    print("  3. Ver documentación completa:")
    print("     cat IMPROVEMENTS_v1.1.md\n")


if __name__ == "__main__":
    demo_roles_and_responsibilities()
